# Semaforo
Utilização de semáforos juntamente com Threads em Java. Essa aplicação foi criada para a disciplina de Sistemas Operacionais I do curso
superior tecnológico em Análise e Desenvolvimento de Sistemas da FATEC Zona Leste, tendo como professor Leandro Colevati. A aplicação é 
toda ambientada em 8bits onde há quatro carros dentro de um cruzamento esperando o semáforo ficar verde para que possam partir. O uso de
semáforos faz com que ocorra um sincronismo de Threads.
